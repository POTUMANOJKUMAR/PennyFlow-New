// import React, { useState } from "react";
// import "./styles.scss";
// import NormalButton from "../../components/NormalButton";
// import assets from "../../assets";
// import NormalInput from "../../components/inputField";
// import NormalModal from "../../components/NormalModal";
// const AutomaticCollectionModal = () => {
//   // const handle = () => {
//   //   setModal(!modal);
//   // };
//   //   const [todos,setTodos]=useState([{
//   //     id:Math.random(),
//   //     title:"0"
//   //   }])
//   //   const[todo,setTodo]=useState("")
//   //  function handle(){
//   // if(todo){
//   // setTodos([...todos,{id:Math.random(),title:todo}])

//   // setTodo("")}
//   // console.log(todos)
//   //   }
//   //   const delect=(id)=>{
//   //     const newtodo=todos.filter(item=>item.id !== id)
//   //     setTodos(newtodo)
//   //   }
//   return <></>;
// };

// export default AutomaticCollectionModal;
